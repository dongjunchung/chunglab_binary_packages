

setClass( Class="bslda",
    representation=representation(
        data="list",
        init="list",
        result="list"
        )
)

