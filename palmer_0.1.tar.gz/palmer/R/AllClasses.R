
# bin-level data

setClass( Class="palmer",
    representation=representation(
        data="matrix",
        init="list",
        result="list"
        )
)

