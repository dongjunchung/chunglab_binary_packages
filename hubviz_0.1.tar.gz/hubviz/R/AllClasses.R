
# bin-level data

setClass( Class="hubviz",
    representation=representation(
        data="matrix",
        init="list",
        result="list"
        )
)

